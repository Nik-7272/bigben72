function toggleMenu() {
  let menu = document.getElementById('menu');
  menu.classList.toggle('active');
}